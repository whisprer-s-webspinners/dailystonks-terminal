# DailyStonks Modular Report Engine (prototype)

This repo is a practical, modular "card + slots" report engine for DailyStonks mailouts.

## Quickstart

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt

# (Option A) install editable
pip install -e .

# (Option B) run without install
# Windows PowerShell: $env:PYTHONPATH = (Get-Location)
# Linux/macOS: export PYTHONPATH=.

# Generate a report (HTML) for a small S&P500 subset (fast)
python scripts/run_report.py --tier black --out out/report.html --universe sp500 --max-universe 60 --tickers SPY,QQQ,AAPL,MSFT,NVDA
```

## Concepts

- **Card**: a module that produces charts/tables + metrics + bullet narrative.
- **Slots**: stable layout positions in the email/terminal.
- **Tier presets**: Free/Basic/Pro/Black choose which slots exist and default cards.
- **Rotation-ready**: selection engine supports locked vs rotating slots (policy-driven).

## Data

S&P500 constituent list is bundled in `data/sp500_constituents.csv` (open dataset derived from Wikipedia).

Market data is downloaded via `yfinance` and cached to Parquet under `.cache/`.

## Notes

This is a prototype focused on correctness and modularity.

## Live terminal / on-screen dashboard

The engine now includes a local terminal controller that reuses the exact same card registry, slot config, tier defaults, yfinance data path, and HTML renderer as the email/report system.

Install as normal:

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
pip install -e .
```

Launch the live terminal:

```bash
dailystonks-live --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d
```

Or without editable install:

```bash
# Windows PowerShell
.\scripts\run_live_terminal.ps1 --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d

# Linux/macOS
./scripts/run_live_terminal.sh --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d
```

Inside the `stonks>` prompt:

```text
open report
open slot S06
open slot S06 reversal.magic_full_chart
open card price.candles_enhanced
slots
cards risk
cards heavy
set tickers SPY,QQQ,NVDA,TSLA
set interval 5m
set refresh auto
views
refresh all
stop all
exit
```

Each `open ...` command generates a local auto-refreshing HTML page and opens it in your browser. The terminal continues running in the background and regenerates the page on the configured cadence; the browser page reloads itself.

Useful launch flags:

```bash
dailystonks-live --interval 5m --refresh-seconds auto
# Pick an ephemeral local port and do not open a browser automatically
dailystonks-live --port 0 --no-browser
# Smoke-test without Yahoo/yfinance network access
dailystonks-live --offline-synth --once card:price.candles_basic
```

Notes:

- yfinance is a polling/candle source, not a true tick-stream. `--refresh-seconds auto` maps the selected interval to a practical refresh cadence: for example `1m` => 60 seconds, `5m` => 300 seconds, `1d` => 900 seconds.
- The normal email/report cache behaviour is preserved. Live views pass a cache TTL so `TODAY` cache files expire before the next live refresh instead of locking the viewer to stale data.
- Matplotlib rendering is serialised internally so multiple live browser views can run without figures trampling each other.
