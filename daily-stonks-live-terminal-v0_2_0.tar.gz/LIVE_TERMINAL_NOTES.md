# DailyStonks live terminal patch

This bundle adds a local terminal-controlled live dashboard to the DailyStonks engine.

## New entry points

From `dailystonks/engine` after installing requirements:

```bash
pip install -e .
dailystonks-live --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d
```

Without editable install:

```powershell
.\scripts\run_live_terminal.ps1 --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d
```

```bash
./scripts/run_live_terminal.sh --tier black --tickers SPY,QQQ,AAPL,MSFT --interval 1d
```

## Terminal commands

```text
open report
open slot S06
open slot S06 reversal.magic_full_chart
open card price.candles_enhanced
slots
cards risk
cards heavy
set tickers SPY,QQQ,NVDA,TSLA
set interval 5m
set refresh auto
views
refresh all
stop all
exit
```

## Smoke tests run here

```bash
PYTHONPATH=. python -m dailystonks.live_terminal --help
PYTHONPATH=. python -m dailystonks.live_terminal --offline-synth --no-browser --once card:price.candles_basic
PYTHONPATH=. python -m dailystonks.live_terminal --offline-synth --no-browser --once slot:S06
PYTHONPATH=. python -m dailystonks.live_terminal --offline-synth --no-browser --once report
PYTHONPATH=. python scripts/run_report.py --offline-synth --tickers SPY,QQQ,AAPL --max-universe 20
```

All passed in the sandbox.
